create view VIEW_X1 as
  select "ID","USERNAME","PASSWORD","ZIP","ADRESS" from shop_user
/

